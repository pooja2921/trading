<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Corporate;
use App\Models\Tanent;
use Auth;
use App\Models\State;
use App\Models\City;
use  App\Models\Country;

class CorporateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $corporates=Corporate::orderBy('created_at','DESC')->paginate(10);
         return view('corporate.index',compact('corporates'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $states= State::get();
        $cities=City::get();
        $countries=Country::get();
        return view('corporate.create',compact('states','cities','countries'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //return $request;
        $request['first_name']=ucfirst(strtolower(trans($request->first_name)));
        $request['middle_name']=ucfirst(strtolower(trans($request->middle_name)));
        $request['last_name']=ucfirst(strtolower(trans($request->last_name)));
        $request['mobile']='+'.$request->coun_code.$request->mobile;
        $tanents=Tanent::where('id','1')->select('id')->first();
        $request['company_id']=$tanents->id;

        $request['address_1']=ucwords(strtolower($request->address_1));
        $request['address_2']=ucwords(strtolower($request->address_2));
        //$request['user_id']=auth()->user()->id;
        $corporate=Corporate::create($request->except('_token'));
        return redirect()->route('corporate.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $corporate=Corporate::find($id);
        $states= State::get();
        $cities = City::get();
        return view('corporate.edit',compact('states','cities','corporate'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //return $request;
        if($request->coun_code !=''){
        $request['mobile']='+'.$request->coun_code.$request->mobile;
        }
        $request['first_name']=ucfirst(strtolower(trans($request->first_name)));
        $request['middle_name']=ucfirst(strtolower(trans($request->middle_name)));
        $request['last_name']=ucfirst(strtolower(trans($request->last_name)));

        $request['address_1']=ucwords(strtolower($request->address_1));
        $request['address_2']=ucwords(strtolower($request->address_2));
        $client=Corporate::where('id',$id)->update($request->except('_token','_method','coun_code'));
        return redirect()->back();
    }

    public function corpstatus(Request $request,$id)
    {
        try{
            //return $id;
            //return $request;
            $corporate = Corporate::where('id',$id)->update(['status'=>$request['stat']]);
           return \Response::json(["status" => "success", "message" => "Corporate updated successfully!"]);
        }catch (Exception $e) {
            return \Response::json(["status" => "danger", "message" => $e->getMessage()]);
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function corpdelete($id){
        //return $id;
        
         $corporate = Corporate::where('id',$id)->forceDelete();
         
        return \Response::json(['status'=>'success', 'message'=>'corporate deleted successfully.']);

    }
}
