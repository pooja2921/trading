@extends('inventory.layout') 
@section('title', 'Edit Items')
@section('content')
    <!-- push external head elements to head -->
    @push('head')
        <link rel="stylesheet" href="{{ asset('plugins/select2/dist/css/select2.min.css') }}">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.css">
    @endpush

    
    <div class="container-fluid">
        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ik ik-user-plus bg-blue"></i>
                        <div class="d-inline">
                            <h5>{{ __('Edit Items')}}</h5>
                            <span>{{ __('Edit Items')}}</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="{{url('dashboard')}}"><i class="ik ik-home"></i></a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">{{ __('Edit Items')}}</a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- start message area-->
            @include('include.message')
            <!-- end message area-->
            <div class="col-md-12">
                <div class="card ">
                    <div class="card-header">
                        <h3>{{ __('Add Items')}}</h3>
                    </div>
                    <div class="card-body">
                        <form class="forms-sample" method="POST" action="{{ route('items.update',$items->id) }}" enctype= multipart/form-data>
                        @csrf
                        @method('PUT')
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                       <label class="d-block">Parent Category</label>
                                        <select  class="form-control parentcat" name="category_id" data-url="{{url('/')}}">

                                        <option value="">Select Category</option> 
                                          @foreach($category as $cat)
                                            <option value="{{$cat->id}}" {{ isset($cat->id) && $cat->id == $items->category_id ? 'selected' :''}}>{{$cat->name}}</option> 
                                          @endforeach
                            
                                        </select>
                                    </div>
                                    <div class="form-group subcategory">
                                        <label class="d-block">Sub Category</label>
                                        <select  class="form-control subcat" name="sub_category_id" data-url="{{url('/')}}">

                                        <option value="">Select Category</option> 
                                          @foreach($category as $cat)
                                          @foreach($cat->children as $subcat)
                                            <option value="{{$cat->id}}" {{ isset($subcat->id) && $subcat->id == $items->sub_category_id ? 'selected' :''}}>{{$subcat->name}}</option> 
                                          @endforeach
                                          @endforeach
                            
                                        </select>
                                    </div>
                                    <div class="form-group childcategory" >
                                        <label class="d-block">child Category</label>
                                        <select  class="form-control childcat" name="childcategory_id" data-url="{{url('/')}}">

                                        <option value="">Select Category</option> 
                                          @foreach($childcategory as $cat)
                                          @foreach($cat->children as $child)
                                            <option value="{{$child->id}}" {{ isset($child->id) && $child->id == $items->childcategory_id ? 'selected' :''}}>{{$child->name}}</option> 
                                          @endforeach
                                            @endforeach
                            
                                        </select>
                                    </div>

                                    <div class="itemform">
                                        <div class="form-group">
                                            <label for="title">Title<span class="text-red">*</span></label>
                                            <input id="title" type="text" class="form-control" name="name" value="{{$items->name}}" placeholder="Enter title" required="">
                                            <div class="help-block with-errors"></div>


                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="title">Brand<span class="text-red">*</span></label>
                                            <input id="Brand" type="text" class="form-control" name="brand" value="{{$items->brand}}" placeholder="Enter Brand" required="">
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Model Details<span class="text-red">*</span></label>
                                            <input id="item" type="text" class="form-control" name="model_details" value="{{$items->model_details}}" placeholder="Enter >Model Details" required="">
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label>Description</label>
                                            <textarea class="form-control" name="description" rows="2">{{$items->description}}</textarea>

                                        </div>

                                        <div class="form-group">
                                            <label for="country">UOM</label>
                                            <select  class="form-control" name="measurement_id" id="measurement" >

                                                <option value="">Select Unit</option> 
                                                    @foreach($measurements as $measurement)

                                                    @if($measurement->id==$items->measurement_id)
                                                        <option value="{{$measurement->id}}" selected="selected">{{$measurement->name}}</option>

                                                    @else
                                                    
                                                        <option value="{{$measurement->id}}">{{$measurement->name}}</option> 
                                                    @endif  
                                                    @endforeach
                                                
                                                </select>
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        {{--<div class="form-group">
                                            <label>Item Images</label>
                                            <div class="input-images" data-input-name="itemimages" data-label="Drag & Drop  images here or click to browse"></div>
                                        </div>--}}
                                    </div>
                                    
                                    </div>

                                    <div class="col-sm-4 formitm" >

                                        <div class="form-group">
                                            <label for="price">Image</label>
                                            @if(isset($items->image))
                                            {{-- <span class="remove_image" style="display:flex;" data-id="{{$items->id}}" data-delete_url="{{url('deleteimg',$items->id)}}">
                                            <i class="fa fa-times"></i>
                                            </span>--}}
                                            <input type="file" id="dropify" class="dropify" data-default-file=" {{ url('images/upload/item/'.$items['image'])}}" name="file">
                                            
                                            @endif
                                            
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Size<span class="text-red">*</span></label>
                                            <input id="Size" type="text" class="form-control" name="size" value="{{$items->size}}" placeholder="Enter Size" required="">
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Warranty<span class="text-red">*</span></label>
                                            <input id="Warranty" type="text" class="form-control" name="warranty" value="{{$items->warranty}}" placeholder="Enter Warranty" required="">
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Lifecycle<span class="text-red">*</span></label>
                                            <input id="Lifecycle" type="text" class="form-control" name="lifecycle" value="{{$items->lifecycle}}" placeholder="Enter Lifecycle" required="">
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Country<span class="text-red">*</span></label>
                                            <input id="Country" type="text" class="form-control" name="country" value="{{$items->country}}" placeholder="Enter Country" required="">
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        
                                        

                                        <div class="form-group">
                                            <label for="available">MATERIAL FORM<span class="text-red">*</span></label>
                                            <input id="available" type="text" class="form-control" name="product_nature" value="{{$items->product_nature}}" placeholder="Enter MATERIAL FORM" required="">
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="available">Packing Volume</label>
                                            <input id="volume" type="text" class="form-control" name="packing_volume" value="{{$items->packing_volume}}" placeholder="Enter Packing Volume">
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">{{ __('Update')}}</button>
                                    </div>
                                </div>
                            </div>
                        
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- push external js -->
    @push('script') 
    <!-- <script>
        $(document).ready(function() {
            
            $('.itemform').css("display", "none");
            $('.formitm').css("display", "none");
            
        });
    </script> -->
    <script>
        $('.parentcat').change(function() { 
            var parentid = $('.parentcat option:selected').val();
            //alert(parentid);
            var publicurl= $(this).data('url');
            //alert(publicurl);
            if(parentid!=''){

                $.ajax({
                    url:publicurl+'/getchildcat/'+parentid,
                    type:'GET',
                    data:{'id':parentid},
                    success:function(data){
                        //console.log(data);
                        var row='';
                            row+='<label class="d-block">Sub Category</label>';
                            row+='<select class="form-control subcat" name="sub_category_id" data-url='+publicurl+'>';
                            row+='<option value=>Select Parent</option>';
                            jQuery.each(data, function(i, cat){
                                row+='<option value='+cat['id']+'>'+cat['name']+'</option>';
                            });
                            row+='</select>';
                        
                            $('.subcategory').html(row);
                    }
                });
              
            }
        });

        
    </script>
    <script>
        $(document).on('change', '.subcat', function() {
            //alert('dbvgdfdf');
            var parentid = $('.subcat option:selected').val();
            //alert(parentid);
            var publicurl= $(this).data('url');
            //alert(publicurl);
            if(parentid!=''){

                $.ajax({
                    url:publicurl+'/getsubcat/'+parentid,
                    type:'GET',
                    data:{'id':parentid},
                    success:function(res){
                        //console.log(res);
                        var row='';
                            row+='<label class="d-block">Sub sub-Category</label>';
                            row+='<select class="form-control childcat" name="childcategory_id" data-url='+publicurl+'>';
                            row+='<option value=>Select Parent</option>';
                            jQuery.each(res, function(i, childcat){
                                row+='<option value='+childcat['id']+'>'+childcat['name']+'</option>';
                            });
                            row+='</select>';
                        
                            $('.childcategory').html(row);
                            $('.itemform').css("display", "block");
                            $('.formitm').css("display", "block");
                    }
                });
            }
        });
    </script>
    <script>
        $(document).on('change', '.childcat', function() {
            $('.itemform').css("display", "block");
            $('.formitm').css("display", "block");
        });
    </script>
    <script src="https://unpkg.com/@yaireo/tagify"></script>
<script src="https://unpkg.com/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
<link href="https://unpkg.com/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />
<script src="{{url('js/tagify.bundle.js')}}"></script> 
    <script src="{{url('js/item_custom.js')}}"></script>
    
    <script type="text/javascript">
        $(function () {
        $('#dropify').dropify();
        });
    </script>
    <!-- image -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"></script>
     
    @endpush
@endsection
