@extends('inventory.layout') 
@section('title', 'Add Product')
@section('content')
    <!-- push external head elements to head -->
    @push('head')
        <link rel="stylesheet" href="{{ asset('plugins/select2/dist/css/select2.min.css') }}">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.css">
    @endpush

    
    <div class="container-fluid">
        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ik ik-user-plus bg-blue"></i>
                        <div class="d-inline">
                            <h5>{{ __('Add Product')}}</h5>
                            <span>{{ __('Create new Product')}}</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="{{url('dashboard')}}"><i class="ik ik-home"></i></a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">{{ __('Add Product')}}</a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- start message area-->
            @include('include.message')
            <!-- end message area-->
            <div class="col-md-12">
                <div class="card ">
                    <div class="card-header">
                        <h3>{{ __('Add Product')}}</h3>
                    </div>
                    <div class="card-body">
                        <form class="forms-sample" method="POST" action="{{ route('items.store') }}" enctype= multipart/form-data>
                        @csrf
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                       <label class="d-block">Product Group</label>
                                        <input id="search" type="text" class="form-control parentcat" name="category_id" value="" placeholder="Enter Category" required="" data-url="{{url('getchildcat')}}" data-public="{{url('/')}}">
                                    </div>
                                    <div class="form-group subcategory" style="display: none;">
                                    </div>
                                    <div class="form-group childcategory" >
                                    </div>
                                    <!--<div class="form-group childsubcategory" >
                                    </div> -->
                                    <div class="itemform">
                                        <div class="form-group">
                                            <label for="title"> Product Name<span class="text-red">*</span></label>
                                            <input id="title" type="text" class="form-control" name="name" value="" placeholder="Enter  Product Name" required="">
                                            <div class="help-block with-errors"></div>


                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="title">Brand<span class="text-red">*</span></label>
                                            <input id="Brand" type="text" class="form-control" name="brand" value="" placeholder="Enter Brand" required="">
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Model Details</label>
                                            <input id="item" type="text" class="form-control" name="model_details" value="" placeholder="Enter Model Details">
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Size</label>
                                            <div class="row">
                                            <div class="col-sm-6">
                                                <input id="Size" type="text" class="form-control" name="size" value="" placeholder="Enter Size Like 10" >
                                            </div>
                                            <div class="col-sm-6">
                                            <input id="sizeunit" type="text" class="form-control" name="sizeunit" value="" placeholder="Enter Like MM" >
                                            </div>
                                           
                                        </div>
                                    </div>

                                        <div class="form-group">
                                            <label>Other Specifications</label>
                                            <textarea class="form-control" name="description" rows="2"></textarea>

                                        </div>

                                        <div class="form-group">
                                            <label for="country">UOM</label>
                                            <select  class="form-control" name="measurement_id" id="measurement" >

                                                <option value="">Select Unit</option> 
                                                    @foreach($measurements as $measurement)
                                                        
                                                            <option value="{{$measurement->id}}">{{$measurement->name}}</option> 
                                                        
                                                    @endforeach
                                                
                                                </select>
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <!-- <div class="form-group">
                                            <label for="title">Product Image Link</label>
                                            <input id="p_image_link" type="text" class="form-control" name="product_image_link" value="" placeholder="Enter Product Image Link">
                                            <div class="help-block with-errors"></div>
                                        </div> -->

                                        <div class="form-group">
                                            <label for="price">Image</label>
                                            <input type="file" id="dropify" class="dropify" data-default-file=" https://cdn.example.com/front2/assets/img/logo-default.png " name="file">
                                        </div>

                                        

                                        {{--<div class="form-group">
                                            <label>Item Images</label>
                                            <div class="input-images" data-input-name="itemimages" data-label="Drag & Drop  images here or click to browse"></div>
                                        </div>--}}
                                    </div>
                                    
                                    </div>

                                    <div class="col-sm-4 formitm" >

                                        <div class="form-group">
                                            <label for="title">Reference Link</label>
                                            <input id="p_image_link" type="text" class="form-control" name="reference_Link" value="" placeholder="Enter Reference Link" >
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Video Link</label>
                                            <input id="video" type="text" class="form-control" name="video_link" value="" placeholder="Enter Video Link" >
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Image Link</label>
                                            <input id="image_link" type="text" class="form-control" name="image_link" value="" placeholder="Enter Image Link" >
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        

                                        <div class="form-group">
                                            <label for="title">Warranty (In month)</label>
                                            <input id="Warranty" type="text" class="form-control" name="warranty" value="" placeholder="Enter Warranty" >
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Lifecycle</label>
                                            <input id="Lifecycle" type="text" class="form-control" name="lifecycle" value="" placeholder="Enter Lifecycle" >
                                            <div class="help-block with-errors"></div>
                                        </div>

                                        <div class="form-group">
                                            <label for="title">Country</label>
                                        <select  class="form-control" name="country_id" id="country" >
                                        <option value="">Select Country</option> 
                                            @foreach($countries as $country)
                                                <option value="{{$country->id}}">{{$country->name}}</option> 
                                             @endforeach
                                        
                                        </select>
                                    </div>
                                        <!-- <div class="form-group">
                                            <label for="title">Country</label>
                                            <input id="Country" type="text" class="form-control" name="country" value="" placeholder="Enter Country" >
                                            <div class="help-block with-errors"></div>
                                        </div> -->

                                        
                                        

                                        <div class="form-group">
                                            <label for="available">MATERIAL FORM</label>
                                            <select  class="form-control" name="product_nature" id="pronature" >
                                            <option value="">Select MATERIAL FORM</option> 
                                            
                                                <option value="Solid">Solid</option> 
                                                <option value="Breakable">Breakable</option> 
                                                <option value="Liquid">Liquid</option> 
                                             
                                        
                                        </select>
                                            <!-- <input id="available" type="text" class="form-control" name="product_nature" value="" placeholder="Enter MATERIAL FORM" > -->
                                            
                                        </div>

                                        <div class="form-group">
                                             <label for="available">Packing Volume</label>
                                            <div class="row">
                                            <div class="col-sm-6">
                                                <input id="volume" type="text" class="form-control" name="packing_volume" value="" placeholder="Enter Packing Volume" >
                                            </div>
                                            <div class="col-sm-6">
                                            <input id="volumeunit" type="text" class="form-control" name="volumeunit" value="" placeholder="Enter Like Meter">
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">{{ __('Submit')}}</button>
                                    </div>
                                </div>
                            </div>
                        
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- push external js -->
    @push('script') 
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>

    <script type="text/javascript">

    var route = "{{ url('catsearch') }}";
 $('#search').typeahead({
            source: function (query, process) {
                return $.get(route, {
                    query: query
                }, function (data) {
                    return process(data);
                });
            }
        });

 
    </script>
    <!-- <script>
        $(document).ready(function() {
            
            $('.itemform').css("display", "none");
            $('.formitm').css("display", "none");
            
        });
    </script> -->
    <script>
        $('.parentcat').change(function() { 
            var parent = $('.parentcat').val();
            //alert(parentid);
            var publicurl= $(this).data('url');
            //alert(publicurl);
            var public=$(this).data('public');
            if(parent!=''){

                $.ajax({
                    url:publicurl,
                    type:'GET',
                    data:{'name':parent},
                    success:function(data){
                        //console.log(data);
                        var row='';
                            row+='<label class="d-block">Sub Category</label>';
                            row+='<select class="form-control subcat" name="sub_category_id" data-url='+public+'>';
                            row+='<option value=>Select Parent</option>';
                            jQuery.each(data, function(i, cat){
                                row+='<option value='+cat['id']+'>'+cat['name']+'</option>';
                            });
                            row+='</select>';
                             $('.subcategory').css('display','block');
                            $('.subcategory').html(row);
                    }
                });
              
            }
        });

        
    </script>
    <script>
        $(document).on('change', '.subcat', function() {
            //alert('dbvgdfdf');
            var parentid = $('.subcat option:selected').val();
            //alert(parentid);
            var publicurl= $(this).data('url');
            //alert(publicurl);
            if(parentid!=''){

                $.ajax({
                    url:publicurl+'/getsubcat/'+parentid,
                    type:'GET',
                    data:{'id':parentid},
                    success:function(res){
                        console.log(res);
                        var row='';
                            row+='<label class="d-block">Sub sub-Category</label>';
                            row+='<select class="form-control childcat" name="childcategory_id" data-url='+publicurl+'>';
                            row+='<option value=>Select Parent</option>';
                            jQuery.each(res, function(i, childcat){
                                row+='<option value='+childcat['id']+'>'+childcat['name']+'</option>';
                            });
                            row+='</select>';
                        
                            $('.childcategory').html(row);
                            $('.itemform').css("display", "block");
                            $('.formitm').css("display", "block");
                    }
                });
            }
        });
    </script>
    <script>
        $(document).on('change', '.childcat', function() {
            $('.itemform').css("display", "block");
            $('.formitm').css("display", "block");
        });
    </script>
    <script src="https://unpkg.com/@yaireo/tagify"></script>
<script src="https://unpkg.com/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
<link href="https://unpkg.com/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />
<script src="{{url('js/tagify.bundle.js')}}"></script> 
    <script src="{{url('js/item_custom.js')}}"></script>
    
    <script type="text/javascript">
        $(function () {
        $('#dropify').dropify();
        });
    </script>
    <!-- image -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"></script>
     
    @endpush
@endsection
